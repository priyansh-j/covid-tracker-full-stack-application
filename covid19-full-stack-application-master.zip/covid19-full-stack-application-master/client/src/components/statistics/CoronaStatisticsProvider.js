import React, {Component} from 'react';

import CoronaStatisticsContainer from './CoronaStatisticsContainer';

class CoronaStatisticsProvider extends Component {
  render() {
    return <CoronaStatisticsContainer/>;
  }
}

export default CoronaStatisticsProvider;

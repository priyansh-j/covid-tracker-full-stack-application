import React, {Component} from 'react';

import MapComponent from './MapComponent';

class MapProvider extends Component {
  render() {
    return <MapComponent/>;
  }
}

export default MapProvider;
